
package com.example.myapplication.customer_db;


import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

public class CusDatabaseHelper extends SQLiteOpenHelper {

    private static final String DATABASE_NAME = "customer.db";
    private static final int DATABASE_VERSION = 3; // 버전 업데이트 + 스키마 변경될 때마다 해줘야 된다네요

    // Customer 테이블 생성 쿼리
    private static final String SQL_CREATE_CUSTOMER_TABLE =
            "CREATE TABLE Customer (" +
                    "id INTEGER PRIMARY KEY AUTOINCREMENT," +
                    "name TEXT," +
                    "phone TEXT," +
                    "customer_id TEXT," +
                    "password TEXT," +
                    "nickname TEXT" +
                    ")";


    public CusDatabaseHelper(Context context) {
        super(context, DATABASE_NAME, null, DATABASE_VERSION);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        // 테이블 생성
        db.execSQL(SQL_CREATE_CUSTOMER_TABLE);
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        // 데이터베이스 업그레이드 시 호출됨
        db.execSQL("DROP TABLE IF EXISTS Customer");
        onCreate(db);
    }


}