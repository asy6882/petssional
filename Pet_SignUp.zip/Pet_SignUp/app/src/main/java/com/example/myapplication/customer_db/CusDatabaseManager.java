
package com.example.myapplication.customer_db;


import android.annotation.SuppressLint;
import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import java.util.ArrayList;
import java.util.List;

public class CusDatabaseManager {

    private CusDatabaseHelper dbHelper;
    private SQLiteDatabase db;

    public CusDatabaseManager(Context context) {
        dbHelper = new CusDatabaseHelper(context);
    }

    public void open() {
        db = dbHelper.getWritableDatabase();
    }

    public void close() {
        dbHelper.close();
    }

    // Customer 추가
    public long addCustomer(String name, String phone, String customer_id, String password, String nickname) {
        ContentValues values = new ContentValues();
        values.put("name", name);
        values.put("phone", phone);
        values.put("customer_id", customer_id);
        values.put("password", password);
        values.put("nickname", nickname);
        return db.insert("Customer", null, values);
    }

    //모든 Customer 조회
    //모든 고객 정보를 조회하여 필요한 경우 화면에 표시하거나 다른 기능에 활용하기 위해 사용될 수 있습니다.
    //관리자 패널 or 사용자 정보 관리 기능 등에서 사용 가능. ex 관리자 패널 - 모든 고객 정보를 조회하여 표시/특정 조건에 따라 검색 가능 또는 사용자가 자신의 프로필을 확인/다른 사용자의 정보를 검색하는 경우에도 이 기능을 사용 가능.
    //이 코드는 애플리케이션의 다른 부분에서 호출되어 고객 정보를 가져오는데 사용. 사용자 인터페이스(UI)에서 이 정보를 표시하거나 다른 데이터 처리 로직에서 필요한 경우 호출될 수 있습니다.
    //데이터베이스와 사용자 인터페이스 간의 중간 매개체 역할
    public List<String> getAllCustomers() {
        List<String> customers = new ArrayList<>();
        Cursor cursor = db.rawQuery("SELECT * FROM Customer", null);
        if (cursor.moveToFirst()) {
            do {
                @SuppressLint("Range") String name = cursor.getString(cursor.getColumnIndex("name"));
                @SuppressLint("Range") String phone = cursor.getString(cursor.getColumnIndex("phone"));
                @SuppressLint("Range") String customer_id = cursor.getString(cursor.getColumnIndex("customer_id"));
                @SuppressLint("Range") String password = cursor.getString(cursor.getColumnIndex("password"));
                @SuppressLint("Range") String nickname = cursor.getString(cursor.getColumnIndex("nickname"));
                customers.add("Name: " + name + ", Phone: " + phone + ", Customer ID: " + customer_id + ", password: " + password + ", nickname: " + nickname); // customer_id 추가
            } while (cursor.moveToNext());
        }
        cursor.close();
        return customers;
    }
}