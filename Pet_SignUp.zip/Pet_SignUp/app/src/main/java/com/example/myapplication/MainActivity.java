
package com.example.myapplication;


import androidx.appcompat.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import com.example.myapplication.customer_db.CusDatabaseManager;

public class MainActivity extends AppCompatActivity {

    private EditText etName, et_phone_number, et_id, et_pass, et_nick_name;
    private Button btn_next;
    private CusDatabaseManager databaseManager;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        // 뷰 초기화
        etName = findViewById(R.id.et_name);
        et_phone_number = findViewById(R.id.et_phone_number);
        btn_next = findViewById(R.id.btn_next);
        et_id = findViewById(R.id.et_id);
        et_pass = findViewById(R.id.et_pass);
        et_nick_name = findViewById(R.id.et_nick_name);

        // 데이터베이스 매니저 초기화
        databaseManager = new CusDatabaseManager(this);
        databaseManager.open();

        // 가입 버튼 클릭 시
        btn_next.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // 사용자 입력 받기
                String name = etName.getText().toString();
                String phone = et_phone_number.getText().toString();
                String customer_id = et_id.getText().toString();
                String password = et_pass.getText().toString();
                String nickname = et_nick_name.getText().toString();

                Log.d("MainActivity", "Name: " + name);
                Log.d("MainActivity", "Phone: " + phone);
                Log.d("MainActivity", "Customer ID: " + customer_id);
                Log.d("MainActivity", "Password: " + password);
                Log.d("MainActivity", "Nickname: " + nickname);

                // 데이터베이스에 추가
                long result = databaseManager.addCustomer(name, phone, customer_id, password, nickname);

                // 결과 확인 및 메시지 출력
                if (result != -1) {
                    Log.i("MainActivity", "Customer added successfully");
                    Toast.makeText(MainActivity.this, "회원가입이 완료되었습니다.", Toast.LENGTH_SHORT).show();
                } else {
                    Log.e("MainActivity", "Failed to add customer to database");
                    Toast.makeText(MainActivity.this, "회원가입에 실패했습니다.", Toast.LENGTH_SHORT).show();
                }
            }
        });
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        // 액티비티가 종료될 때 데이터베이스를 닫음
        databaseManager.close();
    }
}